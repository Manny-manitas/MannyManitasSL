var map = L.map('map').setView([38.4159, -0.4360], 17); // Coordenadas de Carrer de Mondúver, 2A, Mutxamel

L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
    attribution: '© OpenStreetMap contributors'
}).addTo(map);

L.marker([38.4159, -0.4360]).addTo(map)
    .bindPopup('Carrer de Mondúver, 2A, 03110 Mutxamel, Alicante')
    .openPopup();
